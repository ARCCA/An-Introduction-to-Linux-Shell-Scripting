#!/bin/bash
# Define a one dimensional array
 MY_ARRAY=(1 2 3 ’raven’)

 # Print out the contents of the third element
 echo "The third element is ${MY_ARRAY[2]}."

 # Return the number of elements in an array
 echo "The array contains ${#MY_ARRAY[@]} elements"

 # Print the contents of the entire array.
 echo "The array consists of: ${MY_ARRAY[@]}"

 # Define a sparse array and print out the contents
 SPARSE_AR[0]=50
 SPARSE_AR[3]='some words'
 echo "Index 0 of spare array is ${SPARSE_AR[0]}."
 echo "Index 1 of spare array is ${SPARSE_AR[1]}."
 echo "Index 2 of spare array is ${SPARSE_AR[2]}."
 echo "Index 3 of spare array is ${SPARSE_AR[3]}."
