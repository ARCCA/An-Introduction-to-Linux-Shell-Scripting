#!/bin/bash

# Assign two variables with integer values.
X=7
Y=12

# Add these two variables together, store the result in a third variable,
# and print out the result
RESULT=$((X+Y))
echo "X + Y = ${RESULT}!"

# Increment the result by 5.
RESULT=$((RESULT+5))
echo "RESULT is now ${RESULT}"

# Divide the result by 5. Remember bash only deals with integers.
DIVISION=$((RESULT/5))
echo "${RESULT} divided by 5 is ${DIVISION}"
