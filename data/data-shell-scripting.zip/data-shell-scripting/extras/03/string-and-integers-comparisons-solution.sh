#!/bin/bash
#Declare two integers for testing
X=3
Y=10

#Perform a comparison on the integers
if [[ $X < $Y ]]; then
  echo "${X} is less than ${Y}"
else
  echo "${X} is not less than ${Y}"
fi

#Declare two strings
A='string1'
B='string2'

if [[ ${A} < ${B} ]]; then
  echo "${A} is less than ${B}"
else
  echo "${A} is not less than ${B}"
fi
