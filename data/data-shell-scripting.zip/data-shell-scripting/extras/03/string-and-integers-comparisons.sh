#!/bin/bash
#Declare two integers for testing
X=3
Y=10

#Perform a comparison on the integers
if [ $X -eq $Y ]; then
  echo "${X} equals ${Y}"
else
  echo "${X} does not equal ${Y}"
fi

#Declare two strings
A='string1'
B='string2'

if [ ${A} != ${B} ]; then
  echo "strings are different"
else
  echo "strings are identical"
fi
