#!/bin/bash
# Write some text to a file
echo "Hello there" >> filetest.txt

#If the file exists then print the text and delete the file,
#otherwise create an error file
if [ -f filetest.txt ]; then
  echo "File found:"
  cat filetest.txt
  rm filetest.txt
else
  echo "File: filetest.txt doesn’t exist"
  touch file_err.log
fi
