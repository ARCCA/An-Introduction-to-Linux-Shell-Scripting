#!/bin/bash
#mkdir script_test1
#mkdir script_test2

echo "text1" > ./script_test1/text1
echo "text2" > ./script_test2/text2

COUNTER=0

#Find all the files in a directory hierarchy that are marked as executable
for line in $(find -iname text*); do
  LINECAT=$(cat $line)
  MY_ARRAY[$COUNTER]="${LINECAT}"
  COUNTER=$((COUNTER + 1))
done

echo "Array contents ${MY_ARRAY[@]}"
